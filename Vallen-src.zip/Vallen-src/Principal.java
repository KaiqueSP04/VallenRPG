//IMPORTANDO A BIBLIOTECA SCANNER
import java.util.Scanner;

//CLASSE ONDE O JOGO SERÁ RODADO
public class Principal {
	// METODO MAIN
	public static void main(String[] args) {
		String msg, status;

		msg = "Floresta VALLEN:\n";
		msg += "\r";
		msg += "\r";
		msg += "No princípio, um cometa caiu na terra, transformando uma antiga floresta\r";
		msg += "em seu santuário e espalhando seus cristais mágicos em sete direções do lugar.\r";
		msg += "Diante desse espetáculo celestial, uma tribo de nômades, tocada pela grandiosidade\r";
		msg += "do evento, encontrou os destroços reluzentes e decidiu erguer ali sua morada,\r";
		msg += "ligando em sete pontas uma muralha, abençoando a região com o nome Vallen.\r";
		msg += "Os fragmentos celestiais transformaram a floresta em um lugar mágico,\r";
		msg += "gerando frutos e transformando-a em um paraíso na terra.\r";
		msg += "Ao longo de séculos os nômades formaram um vilarejo com a missão de proteger os\r";
		msg += "cristais, garantindo a harmonia e a prosperidade da Floresta abençoada.\r";
		System.out.println(msg);

		msg = "Otavius, um habitante do vilarejo, era um cientista fascinado\r";
		msg += "pelos cristais, firmemente convicto de seu potencial extraordinário\r";
		msg += "Sua mente inquieta e ambiciosa o levou a substituir um dos cristai por\r";
		msg += "uma pedra semelhante para seu uso pessoal, sem que a aldeia percebesse\r";
		msg += "Ao aplicá-la em um colar, ele descobriu que conseguia aumentar\r";
		msg += "sua força e vitalidade.\r";
		System.out.println(msg);

		msg = "Você, um jovem morador da aldeia, está caminhando\r";
		msg += "e observa algo estranho acontecendo, decide\r";
		msg += "\r";
		msg += "[1] Investigar para ver ser tem algo rolando realmente\r";
		msg += "[2] Deixar para lá e continuar a caminhar\r";
		System.out.println(msg);

		Scanner escolha = new Scanner(System.in); //CRIANDO SCANNER
		
		// PRIMEIRA ESCOLHA USANDO SCANNER
		int escolhaUm = escolha.nextInt();

		if (escolhaUm == 1) {
			msg = "\r";
			msg += "Guiado pela intuição, você caminha até os cristais e desvenda os mistérios:\r";
			msg += "animais inquietos, e a flora murchando. Uma pedra estranha entre os cristais denuncia\r";
			msg += "um roubo, enquanto anotações estranhas jogadas no chão denunciam a suspeitas sobre Dr.Otavius\r";
			System.out.println(msg);
		} else if (escolhaUm == 2) {
			msg = "\r";
			msg += "Enquanto percorre a aldeia, sinais chamam sua atenção: a flora murchando,\r";
			msg += "e animais agitados. Papeis espalhados pelo chão mencionam os cristais.\r";
			msg += "Uma aura de mistério envolve você aumentando sua suspeitas sobre Otavius, o cientista local.\r";
			System.out.println(msg);
		} else {
			System.out.println("Tome um Decisão");
			System.exit(0);
		}

		// FIM PRIMEIRA ESCOLHA

		msg = "Preocupado, você chama Sarah, sua melhor amiga para caminhar\r";
		msg += "ao anoitecer, a fim de contar suas preocupações.\r";
		msg += "\r";
		msg += "Jogador: Sarah! encontrei uma pedra estranha entre os cristais e anotações suspeitas no chão.\r";
		msg += "Parece que alguém está mexendo com os cristais, talvez até roubando-os.\r";
		msg += "\r";
		msg += "Sarah: Bem que eu estava suspeitando de algo na floresta, percebi que os\r";
		msg += "animais estão aflitos e os frutos murcharam... \r";
		msg += "as coisas parecem que estão perdendo a vida! eu suspeito de alguém...\r";
		msg += "\r";
		msg += "Jogador e Sarah: Dr. Otavius!!!!\r";
		msg += "\r";
		msg += "Caminhando, Você e Sarah, perto da muralha da aldeia, observam Otavius, indo\r";
		msg += "em direção as muralhas adornada com os cristais. Em seu pescoço, observa seu\r";
		msg += "colar canalizado com três pedras. Você lembra do conteúdo das anotações perdidas, que fala:\r";
		msg += "\r";
		msg += "Canalizar as sete pedras garantiria imortalidade, mas cada fragmento\r";
		msg += "aumentaria a força e vitalidade, embora causasse fadiga.\r";

		// CADA PEDRA AUMENTA 8 DE VIDA E 5 DE FORÇA E DIMINUI 1 DE VELOCIDADE

		msg += "Otavius percebe a presença de ambos, e agora eles estão em perigo.\r";
		msg += "\r";
		msg += "Seu coração acelera e a tensão se instala, pois uma decisão crucial\r";
		msg += "deverá ser tomada:\r";
		System.out.println(msg);

		// CRIANDO AS PERSONAGENS

		Personagem jogador = new Personagem();
		jogador.setNome("Jogador");
		jogador.setVida(22);
		jogador.setForca(12);
		jogador.setAgilidade(7);

		Personagem sarah = new Personagem();
		sarah.setNome("Sarah");
		sarah.setVida(22);
		sarah.setForca(12);
		sarah.setAgilidade(7);

		Personagem otavius = new Personagem();
		otavius.setNome("Otavius");
		otavius.setVida(46);
		otavius.setForca(27);
		otavius.setAgilidade(4);

		// MOSTANDO OS STATUS DOS PERSONAGENS

		status = "--------------------\r";
		status += jogador.getNome() + "\r";
		status += "Vida: " + jogador.getVida() + "\r";
		status += "Força: " + jogador.getForca() + "\r";
		status += "Agilidade: " + jogador.getAgilidade() + "\r";
		status += "--------------------\r";
		status += sarah.getNome() + "\r";
		status += "Vida: " + sarah.getVida() + "\r";
		status += "Força: " + sarah.getForca() + "\r";
		status += "Agilidade: " + sarah.getAgilidade() + "\r";
		status += "--------------------\r";
		status += otavius.getNome() + "\r";
		status += "Vida: " + otavius.getVida() + "\r";
		status += "Força: " + otavius.getForca() + "\r";
		status += "Agilidade: " + otavius.getAgilidade() + "\r";
		status += "--------------------\r";
		System.out.println(status);

		// SEGUNDA ESCOLHA USANDO SCANNER

		msg = "[1] Confrontar Otavius diretamente:\r";
		msg += "Arrisque uma tentativa de combate e tente vencer Otavius.\r";
		msg += "[2] Tentar negociar:\r";
		msg += "Arrisque uma tentativa de negociar com Otavius, buscando convencê-lo a desistir de seus planos malignos.\r";
		System.out.println(msg);

		int escolhaDois = escolha.nextInt();

		if (escolhaDois == 1) {
			msg = "\r";
			msg += "Vocês olham ao redor e veem alguns objetos que\r";
			msg += "podem ser úteis para enfrentar Otavius, e você\r";
			msg += "decide usar:\r";
			msg += "\r";
			msg += "[1] Atacar com pedaço de madeira afiado.\r";
			msg += "[2] Atacar com uma pedra pesada.\r";
			System.out.println(msg);

			int e2c1 = escolha.nextInt(); // ESCOLHA 2 CAMINHO 1

			if (e2c1 == 1 || e2c1 == 2) {
				msg = "\r";
				msg += "Vocês avançam com todas as suas forças usando o que tinham,\r";
				msg += "prontos para enfrentar Otavius.\r";
				System.out.println(msg);
			} else {
				System.out.println("Tome um Decisão");
				System.exit(0);
			}

			msg = "Otavius: Vocês são persistentes, admito. Mas não são páreo para mim!\r";
			msg += "\r";
			msg += "Você: Vamos ver quem sai por cima, Otavius. A aldeia não vai ceder à sua tirania!\r";
			msg += "\r";
			msg += "Ao enfrentarem Otavius diretamente, você e Sarah lutam bravamente, mas sem\r";
			msg += "a comunidade saber do ocorrido, são superados por sua força avassaladora. \r";
			msg += "Otavius, soberbo e ambicioso, mostra-se implacável em sua busca pelos cristais,\r";
			msg += "deixando-os derrotados e gravemente feridos.\r ";
			System.out.println(msg);
		} else if (escolhaDois == 2) {
			msg = "\r";
			msg += "Você: Otavius, Não precisa ser assim. Juntos podemos encontrar uma solução\r";
			msg += "que beneficie a todos.\r";
			msg += "\r";
			msg += "Otavius ri, um som frio e sarcástico.\r";
			msg += "\r";
			msg += "Otavius: Você acha que eu vou desistir por causa de palavras vazias?\r";
			msg += "Que tolice! Você é ingênuo demais para entender minha determinação.\r";
			msg += "\r";
			msg += "[1] Falar sobre o valor da comunidade e o dever de proteger\r";
			msg += "a floresta de Vallen e seus tesouros ancestrais.\r";
			msg += "[2] Falar que ele não está pensando direito e que ele não precisa disso.\r";
			System.out.println(msg);

			int e2c2 = escolha.nextInt(); // ESCOLHA 2 CAMINHO 2

			if (e2c2 == 1 || e2c2 == 2) {
				msg = "\r";
				msg += "Otavius:Chega de conversa fiada!\r";
				msg += "Você é uma pedra no meu caminho, e eu não tolerarei mais obstáculos.\r";
				System.out.println(msg);
			} else {
				System.out.println("Tome um Decisão");
				System.exit(0);
			}
			msg = "Otavius avança implacavelmente contra você e Sarah, e apesar de seus esforços,\r";
			msg += "vocês são derrotados. Gravemente feridos, vocês são deixados à mercê de Otavius,\r";
			msg += "incapazes de impedir sua busca pelos cristais restantes.\r";
			msg += "A comunidade permanece alheia ao perigo iminente, e a esperança parece distante para vocês.\r";
			System.out.println(msg);
		} else {
			System.out.println("Tome um Decisão");
			System.exit(0);
		}

		// FIM SEGUNDA ESCOLHA

		// LOGICA DE BATALHA STATUS JOGADOR + SARAH > OTAVIUS

		int sv = jogador.getVida() + sarah.getVida(); // SOMA VIDA JOGADOR + SARAH
		int sf = jogador.getForca() + sarah.getForca(); // SOMA FORÇA JOGADOR + SARAH

		status = "--------------------\r";
		status += jogador.getNome() + " + " + sarah.getNome() + "\r";
		status += "Vida: " + sv + "\r";
		status += "Força: " + sf + "\r";
		status += "--------------------\r";
		status += otavius.getNome() + "\r";
		status += "Vida: " + otavius.getVida() + "\r";
		status += "Força: " + otavius.getForca() + "\r";
		status += "--------------------\r";
		System.out.println(status);

		if (sv > otavius.getVida() && sf > otavius.getForca()) {
			msg = "Você e sarah derrotam Otavius";
			System.out.println(msg);
		} else {
			msg = "Você e Sarah ainda nao supera a força de Otavius, ";
			msg += "e foram derrotados";
			System.out.println(msg);
		}

		msg = "Após retornarem feridos à aldeia,\r";
		msg += "Você e Sarah revelam a verdade sobre Otavius, diante da revolta dos moradores.\r";
		msg += "Agora, com o apoio da comunidade,\r";
		msg += "planejam uma nova estratégia para derrotá-lo e proteger a aldeia.\r";
		msg += "\r";
		msg += "Você e Sarah estão recuperados da lesão.\r";
		msg += "\r";
		msg += "Sabendo da ameaça iminente, o mestre ancião da vila,\r";
		msg += "Gaius, se oferece para treinar você e Sarah.\r";
		msg += "Ele propõe iniciar um treinamento intenso para\r";
		msg += "preparar todos para o confronto iminente com o cientista.\r";
		msg += "Para isso, ele faz duas propostas para você!\r";
		msg += "\r";
		msg += "[1] Você se tornara um guerreiro e Sarah uma sentinela\r";
		msg += "[2] Você se tornara um arqueiro e Sarah uma Mercenaria\r";
		System.out.println(msg);

		// TERCEIRA ESCOLHA

		int escolhaTres = escolha.nextInt();

		if (escolhaTres == 1) {
			int jogadorVida, jogadorForca, sarahVida, sarahForca, sVida, sForca, otaviusVida, otaviusForca;

			Guerreiro guerreiroJogador = new Guerreiro("Jogador", 12, 10, 4);
			Sentinela sentinelaSarah = new Sentinela("Sarah", 8, 6, 2);

			jogadorVida = jogador.getVida() + guerreiroJogador.getVida();
			jogadorForca = jogador.getForca() + guerreiroJogador.getForca();
			sarahVida = sarah.getVida() + sentinelaSarah.getVida();
			sarahForca = sarah.getForca() + sentinelaSarah.getForca();

			msg = "\r";
			msg += "Após um intenso treinamento com Gaius,\r";
			msg += "você se torna um habilidoso Guerreiro\r";
			msg += "e equipou uma espada recebido de Gaius para aprimorar sua força\r";
			msg += "e Sarah se torna uma Sentinela\r";
			msg += "recebendo um arco de Gaius para aprimorar sua força\r";
			System.out.println(msg);
			
			sVida = jogadorVida + sarahVida; // SOMA VIDA JOGADOR + SARAH
			sForca = jogadorForca + sarahForca; // SOMA FORÇA JOGADOR + SARAH
			otaviusVida = otavius.getVida() + 16; //NESSE MOMENTO OTAVIUS ESTÁ COM DUAS PEDRAS A MAIS
			otaviusForca = otavius.getForca() + 10; //NESSE MOMENTO OTAVIUS ESTÁ COM DUAS PEDRAS A MAIS
			
			status = "--------------------\r";
			status += jogador.getNome() + " + " + sarah.getNome() + "\r";
			status += "Vida: " + sVida + "\r";
			status += "Força: " + sForca + "\r";
			status += "--------------------\r";
			status += otavius.getNome() + "\r";
			status += "Vida: " + otaviusVida + "\r";
			status += "Força: " + otaviusForca + "\r";
			status += "--------------------\r";
			System.out.println(status);

		} else if (escolhaTres == 2) {
			int jogadorVida, jogadorForca, sarahVida, sarahForca, sVida, sForca, otaviusVida, otaviusForca;

			Arqueiro arqueiroJogador = new Arqueiro("Jogador", 8, 4, 2);
			Mercenaria mercenariaSarah = new Mercenaria("Sarah", 10, 6, 7);

			jogadorVida = jogador.getVida() + arqueiroJogador.getVida();
			jogadorForca = jogador.getForca() + arqueiroJogador.getForca();
			sarahVida = sarah.getVida() + mercenariaSarah.getVida();
			sarahForca = sarah.getForca() + mercenariaSarah.getForca();

			msg = "\r";
			msg += "Após um intenso treinamento com Gaius,\r";
			msg += "você se torna um habilidoso Arqueiro\r";
			msg += "e equipou um arco recebido de Gaius para aprimorar sua força\r";
			msg += "e Sarah se torna uma Mercenaria\r";
			msg += "recebendo adagas de Gaius para aprimorar sua força\r";
			System.out.println(msg);
			
			sVida = jogadorVida + sarahVida; // SOMA VIDA JOGADOR + SARAH
			sForca = jogadorForca + sarahForca; // SOMA FORÇA JOGADOR + SARAH
			otaviusVida = otavius.getVida() + 16; //NESSE MOMENTO OTAVIUS ESTÁ COM DUAS PEDRAS A MAIS
			otaviusForca = otavius.getForca() + 10; //NESSE MOMENTO OTAVIUS ESTÁ COM DUAS PEDRAS A MAIS
			
			status = "--------------------\r";
			status += jogador.getNome() + " + " + sarah.getNome() + "\r";
			status += "Vida: " + sVida + "\r";
			status += "Força: " + sForca + "\r";
			status += "--------------------\r";
			status += otavius.getNome() + "\r";
			status += "Vida: " + otaviusVida + "\r";
			status += "Força: " + otaviusForca + "\r";
			status += "--------------------\r";
			System.out.println(status);

		} else {
			System.out.println("Tome um Decisão");
			System.exit(0);
		}
		
		//FIM TERCEIRA ESCOLHA

		msg = "Sob sua liderança, os cristais foram protegidos consigo mesmo, \r";
		msg += "afastando o medo do roubo por parte de Otavius. \r";
		msg += "Os habitantes dedicaram-se incansavelmente proteger o que restava dos \r";
		msg += "valiosos cristais, mantendo viva uma chama de \r";
		msg += "esperança durante a espera pelo retorno de Otavius. \r";
		System.out.println(msg);

		msg = "Uma explosão sinaliza ansiedade e tensão,\r";
		msg += "com o retorno da ameaça imponente de Otavius.\r";
		System.out.println(msg);

		msg = "Otavius: Preparem-se para Testemunhar minha ascensão ao poder absoluto!\r";
		msg += "Vallen é apenas o começo da minha grandeza imortal!\r";
		System.out.println(msg);

		msg = "Otavius retorna, mais implacável com quatro cristais canalizados em seu colar, \r";
		msg += "evocando um clima de confronto final entre ele e a aldeia. \r";
		System.out.println(msg);

		msg = "Você, Sarah e os moradores se preparam para a batalha:\r";
		System.out.println(msg);

		//CONSEQUENCIAS DA TERCEIRA ESCOLHA
		
		//SE A TERCEIRA ESCOLHA FOI DE JOGADOR GUERREIRO E SARAH SENTINELA:
		if (escolhaTres == 1) {

			msg = "Com bravura inabalável como a de um guerreiro e uma determinação ardente de uma\r";
			msg += "sentinela, você e Sarah enfrentaram Otavius como verdadeiros heróis.\r";
			System.out.println(msg);

			msg = "Os moradores da vila reúnem-se \r";
			msg += "imediatamente após o ataque conjunto de vocês.\r";
			System.out.println(msg);

			msg = "Otavius subestimou a determinação e a força da aldeia, mesmo quando\r";
			msg += "parte dos moradores estavam em ruínas, sua derrota se tornou inevitável.\r";
			System.out.println(msg);
			
			msg = "Nesse momento crucial, uma oportunidade\r";
			msg += "surge para você derrotar de vez Otavius:\r";
			System.out.println(msg);

			msg = "\r";
			msg += "[1] Derrota-lo ao atacá-lo por trás, em um momento de distração.\r";
			msg += "[2] Você aproveita um momento de distração de Otavius para derrubá-lo\r";
			msg += "com um golpe nas pernas e, em seguida, o imobiliza.\r";
			System.out.println(msg);

			int e3c1 = escolha.nextInt(); // ESCOLHA TRES CAMINHO UM

			if (e3c1 == 1) {

				msg = "\r";
				msg += "Otavius é dilacerado por seu ataque impiedoso,\r";
				msg += "toda Aldeia de Vallen comemora sua ação.\r";
				System.out.println(msg);

			} else if (e3c1 == 2) {

				msg = "\r";
				msg += "Otavius, agora imobilizado, é levado para uma prisão exclusiva,\r";
				msg += "cercada por guardiões que o mantêm isolado da comunidade, renegado por completo.\r";
				System.out.println(msg);

			} else {
				System.out.println("Tome um Decisão");
				System.exit(0);
			}

			msg = "Você retira o colar com os quatro cristais de Otavius e os devolve ao seu lugar de direito.\r";
			msg += "Agora, os cristais estão canalizando a energia vital da floresta mais uma vez,\r";
			msg += "restaurando sua magnificência e equilíbrio.\r";
			System.out.println(msg);

			msg = "A normalidade retorna: os animais se acalmam,\r";
			msg += "os frutos voltam a brotar e Otavius é detido permanentemente.\r";
			System.out.println(msg);

			msg = "Você e Sarah, emergem como símbolos inabaláveis de coragem e lealdade\r";
			msg += "incansável a Vallen, admirados por todos na aldeia.\r";
			System.out.println(msg);

		//SE A TERCEIRA ESCOLHA FOI DE JOGADOR ARQUEIRO E SARAH MERCENARIA:
		} else if (escolhaTres == 2) {
			msg = "Após o ataque inicial da aldeia, você, como arqueiro habilidoso, e Sarah, mercenária\r";
			msg += "de força imponente, enfrentam Otavius. Apesar de seus esforços combinados,\r";
			msg += "Otavius consegue imobilizar Sarah em um momento de descuido. \r";
			System.out.println(msg);

			msg = "Otavius: Entregue os cristais que sobraram dessa vila insignificante e sua\r";
			msg += "amiga será poupada. Caso contrário, ela certamente morrerá. A escolha é sua.\r";
			System.out.println(msg);

			msg = "Com o medo de Otavius tirar a vida de Sarah, os moradores interrompem o ataque,\r";
			msg += "esperando sua decisão e deixando o destino da aldeia em suas mãos.\r";
			System.out.println(msg);

			msg = "[1] Opte por salvar Sarah, permitindo que Otavius leve as últimas três pedras.\r";
			msg += "A floresta perderá sua magia, mas todos serão salvos.\r";
			msg += "[2] Proteja a vila e a floresta, mas prepare-se para uma tragédia envolvendo Sarah.\r";
			System.out.println(msg);

			int e3c2 = escolha.nextInt(); // ESCOLHA TRES CAMINHO DOIS

			if (e3c2 == 1) {

				msg = "\r";
				msg += "Após uma rápida análise, você abaixa suas armas e opta por entregar o que resta dos \r";
				msg += "cristais a Otavius. Com seu objetivo alcançado, Otavius se torna imparável.\r";
				System.out.println(msg);

				msg = "Apesar disso, você sente alívio ao ver Sarah bem.\r";
				msg += "Enquanto Vallen nunca mais será o mesmo, tornando-se apenas mais uma floresta \r";
				msg += "em ruínas, a comunidade local terá que se adaptar a esse novo estilo de vida sem a magia.\r";
				System.out.println(msg);

				msg = "Otavius, agora imortal, escapa de Vallen, tornando-se uma ameaça\r";
				msg += "não apenas para a região, mas para o mundo inteiro.\r";
				System.out.println(msg);

			} else if (e3c2 == 2) {

				msg = "\r";
				msg += "Você lança uma flecha certeira em Otavius enquanto ele segura Sarah, atingindo o cordão do seu colar. \r";
				msg += "Em retaliação, Otavius golpeia Sarah em seu pescoço, desencadeando sua fúria e brutalidade. \r";
				msg += "Você dispara várias flechas letais contra Otavius, que, exausto, não consegue evitar, sendo derrotado. \r";
				System.out.println(msg);

				msg = "Em prantos, você se lança sobre o corpo de Sarah, que, em seu último suspiro, diz: \r";
				System.out.println(msg);

				msg += "Sarah: Não derrame lágrimas, conseguimos proteger a vila... \r";
				System.out.println(msg);

				msg = "Mais tarde, durante seu luto, você devolve os cristais ao seu devido lugar, restaurando\r";
				msg += "assim a harmonia, a magia e a paz de Vallen. Porém, a dor em seu peito permanece, incurável.\r";
				System.out.println(msg);

			} else {
				System.out.println("Tome um Decisão");
				System.exit(0);
			}

		} else {
			System.out.println("Tome um Decisão");
			System.exit(0);
		}
		escolha.close();
	}

}
