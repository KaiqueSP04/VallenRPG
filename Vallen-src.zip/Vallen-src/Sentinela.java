//HERANÇA CLASSE SENTINELA ESTÁ HERDANDO PERSONAGEM
public class Sentinela extends Personagem {

	//METODO CONSTRUTOR - SENTINELA
	public Sentinela(String nome, int vida, int forca, int agilidade) {
		this.nome = nome;
		this.vida = vida;
		this.forca = forca;
		this.agilidade = agilidade;
	}
}
