//HERANÇA - CLASSE GUERREIRO ESTÁ HERDANDO PERSONAGEM
public class Guerreiro extends Personagem {
	
	//METODO CONSTRUTOR - GUERREIRO
	public Guerreiro(String nome, int vida, int forca, int agilidade) {
		this.nome = nome;
		this.vida = vida;
		this.forca = forca;
		this.agilidade = agilidade;
		
	}
	
	
	
}
