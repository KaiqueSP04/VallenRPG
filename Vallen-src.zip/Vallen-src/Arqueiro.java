//HERANÇA - CLASSE ARQUEIRO ESTÁ HERDANDO PERSONAGEM
public class Arqueiro extends Personagem {

	//METODO CONSTRUTOR - ARQUEIRO
	public Arqueiro(String nome, int vida, int forca, int agilidade) {
		this.nome = nome;
		this.vida = vida;
		this.forca = forca;
		this.agilidade = agilidade;
	}
}
