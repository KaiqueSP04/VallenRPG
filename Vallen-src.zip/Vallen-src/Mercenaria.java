//HERANÇA - CLASSE MERCENARIA ESTÁ HERDANDO PERSONAGEM
public class Mercenaria extends Personagem {

	//METODO CONSTRUTOR - MERCENARIA
	public Mercenaria(String nome, int vida, int forca, int agilidade) {
		this.nome = nome;
		this.vida = vida;
		this.forca = forca;
		this.agilidade = agilidade;
	}

}
